const check = function () { 
    console.log('Doing some work...') 
} 
 
module.exports = check
